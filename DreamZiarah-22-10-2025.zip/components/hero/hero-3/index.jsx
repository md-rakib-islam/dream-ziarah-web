"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import MainFilterSearchBox from "./MainFilterSearchBox";
import CoverSkeleton from "@/components/skeleton/CoverSkeleton";
import { useDispatch, useSelector } from "react-redux";
import { addCurrentTab } from "@/features/hero/findPlaceSlice";
const index = ({
  onDataAvailable,
  isSuccess,
  isLoading,
  data,
  onMobileDataAvailable,
}) => {
  const { tabs, currentTab } = useSelector((state) => state.hero) || {};
  const dispatch = useDispatch();
  const [navbar, setNavbar] = useState(false);

  const changeBackground = () => {
    if (window.scrollY >= 10) {
      setNavbar(true);
    } else {
      setNavbar(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };
  useEffect(() => {
    if (isSuccess) {
      onMobileDataAvailable(true);
    }
  }, [isSuccess, onMobileDataAvailable]);

  useEffect(() => {
    window.addEventListener("scroll", changeBackground);
    return () => {
      window.removeEventListener("scroll", changeBackground);
    };
  }, []);
  let sliderImageItems = [];
  if (isSuccess) {
    sliderImageItems = data?.homepage_sliders?.map((item) => ({
      ...item,
      image: `${item.image}`,
    }));
  }
  // useEffect(() => {
  //   if (sliderImageItems !== 0) {
  //     onDataAvailable(true);
  //   }
  // }, [onDataAvailable, sliderImageItems]);

  return isLoading ? (
    <CoverSkeleton />
  ) : (
    <>
      {/* Mobile View - Hidden on desktop (>= 576px) */}
      <section
        className="masthead__bg -type-2 z-2 d-sm-none"
        // style={{ backgroundColor: "#3bf6aeff" }}
      >
        <div className="row m-0">
          <div className="col-12 p-0">
            <div
              className={`masthead__tabs  ${
                navbar ? "header-masterhead controls-head  is-sticky" : ""
              }`}
            >
              <div className="tabs -bookmark-2 js-tabs w-100">
                <div
                  className="tabs__controls d-flex items-center js-tabs-controls"
                  style={{
                    backgroundColor: "#015a29ff",
                  }}
                >
                  {tabs?.map((tab) => (
                    <button
                      key={tab?.id}
                      className={`tabs__button px-30 py-15 sm:px-15 sm:py-15 rounded-4 fw-600 text-white js-tabs-button ${
                        tab?.name === currentTab ? "is-tab-el-active" : ""
                      }`}
                      onClick={() => {
                        scrollToTop();
                        dispatch(addCurrentTab(tab?.name));
                      }}
                    >
                      {/* <i className={`${tab.icon} text-20 mr-10 sm:mr-5`}></i> */}
                      {tab?.name}
                    </button>
                  ))}
                </div>
              </div>
              {/* End tabs */}
            </div>
            {/* End .masthead__tabs */}

            <div className="w-100">
              <div
                className="row justify-center m-0"
                style={{
                  backgroundImage:
                    "url(https://imagedelivery.net/dIKhvGtesTiRSxhQ2oKWkA/a59cfc16-7fde-4a50-7103-e6622f883600/public)",
                  backgroundSize: "cover",
                  backgroundRepeat: "no-repeat",
                  opacity: 0.89,
                  height: "120px",
                  width: "100%",
                  backgroundPosition: "center",
                  backgroundAttachment: "local",
                }}
              >
                <div className="col-xl-9 d-lg-flex flex-column justify-content-center align-items-center mt-10">
                  <div className="text-center">
                    <h1
                      className="text-20 lg:text-20 md:text-14  text-white"
                      // data-aos="fade-up"
                      style={{
                        textShadow: "1px 1px 2px rgba(0,0,0,0.5)",
                      }}
                    >
                      Book Your Ziyarat <br />
                      in Makkah and Umrah tour Packages
                    </h1>
                    <p
                      className="text-white text-10 mt-5"
                      // data-aos="fade-up"
                      data-aos-delay="100"
                      style={{
                        textShadow: "1px 1px 2px rgba(0,0,0,0.5)",
                      }}
                    >
                      Find Makkah ziyarat tour and umrah packages with guided
                      ziyarat tours in Saudi Arabia.
                    </p>
                  </div>
                  {/* End hero title */}
                </div>
              </div>
            </div>
          </div>

          {/* End .masthead__content */}
        </div>
        {/* End .container */}
      </section>

      {/* Desktop View - Hidden on mobile (< 576px) */}
      <section className="masthead -type-6 mb-40 d-none d-sm-block">
        <div className="masthead__bg ">
          <Image
            src={sliderImageItems[1]?.cloudflare_image_url}
            width={1920}
            height={600}
            alt="image"
            priority={true}
            onLoad={() => onDataAvailable(true)}
          />
        </div>

        <div
          className="container"
          style={{ position: "relative", top: "70px" }}
        >
          <div className="row justify-center">
            <div className="col-xl-9 d-lg-flex flex-column justify-content-center align-items-center">
              <div className="text-center">
                <h1
                  className="text-45 lg:text-40 md:text-30 text-white"
                  // data-aos="fade-up"
                  style={{
                    textShadow: "1px 1px 2px rgba(0,0,0,0.5)",
                  }}
                >
                  Book Your Ziyarat <br />
                  in Makkah and Umrah tour Packages
                </h1>
                <p
                  className="text-white mt-5"
                  // data-aos="fade-up"
                  data-aos-delay="100"
                  style={{
                    textShadow: "1px 1px 2px rgba(0,0,0,0.5)",
                  }}
                >
                  Find Makkah ziyarat tour and umrah packages with guided
                  ziyarat tours in Saudi Arabia. Visit Haram Sharif and the
                  Prophet’s Mosque with English guides. Get cheap hajj deals and
                  ziyarat places in Makkah list now, spots fill fast!
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="container">
          <div
            className="mainSearch-wrap bg-white shadow-1"
            // data-aos="fade-up"
            data-aos-delay="200"
          >
            <MainFilterSearchBox />
            {/* End tab-filter */}
          </div>
        </div>
      </section>
    </>
  );
};

export default index;
